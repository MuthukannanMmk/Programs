<?php
session_start();

if(!isset($_SESSION['user_name'])){

header("location: login.php");
}
else {

  include("dbcon.php");

  if(isset($_GET['cmt'])){

  $search_id = $_REQUEST['value'];
  $poi=$_REQUEST['po'];
  $ui=$_SESSION['user_name'];echo "$ui";
  if(empty($search_id)){

    echo "<h2><center>Comment Box is Empty..</center></h2>";
    }


    else
    {

        	$insert_query = "insert into cmts
        	(uid,pid,cmt) values
        	('$ui','$poi','$search_id')";


        	if(mysql_query($insert_query)){
        	echo "<script>window.open('index.php','_self')</script>";
        }
      }
}}
?>
