<?php
include("../dbcon.php");
if(isset($_GET['del'])){
	$delete_id = $_GET['del'];
	$delete_query = "delete from allpost where pid='$delete_id' ";
	if(mysql_query($delete_query)){
	echo "<script>alert('Post Has been Deleted')</script>";
	echo
	"<script>window.open('index.php','_self')</script>";
	}
}
?>
