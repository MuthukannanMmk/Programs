<?php
session_start();

if(!isset($_SESSION['user_name'])){

header("location: login.php");
}
else {
?>

<html>
	<head>
		<title>Posts</title>

	<link rel="stylesheet" href="as.css" />
	</head>

<body>
<?php include("common.php") ?>


<div id="cn">
	<div class="h">
		View All Posts
	</div>
	<table id="tab">



		<tr>
			<th>Title</th>
			<th>Category</th>
			<th>Tags</th>
			<th>Photo</th>
			<th>Cotent</th>
			<th>Date</th>
			<th>Author</th>
			<th>Delete</th>
			<th>Edit</th>
		</tr>


	<?php
	include("../dbcon.php");

	$query = "select * from allpost order by 1 DESC";

	$run = mysql_query($query);

	while($row=mysql_fetch_array($run)){
		$id=$row['pid'];
		$t = $row['title'];
		$c = $row['category'];
		$tg = $row['tags'];
		$p = $row['photos'];
		$cn=substr($row['content'],0,30);
		$a=$row['author'];
		$d=$row['dt']

	?>
	<tr align="center">
			<td><?php echo $t; ?></td>
			<td><?php echo $c; ?></td>
			<td><?php echo $tg; ?></td>
			<td><img src="../images/<?php echo $p; ?>"width="80" height="80"></td>
			<td width="1px"><?php echo $cn; ?></td>
			<td><?php echo $d; ?></td>
			<td><?php echo $a; ?></td>
			<td><a href="dlt.php?del=<?php echo $id; ?>"
			>Delete</a></td>
			<td><a href="update.php?edit=<?php echo $id; ?>">Edit</a></td>
		</tr>
	<?php } ?>
	</table>

</div>

</body>
</html>

<?php } ?>
