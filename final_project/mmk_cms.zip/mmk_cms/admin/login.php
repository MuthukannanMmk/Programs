<?php
session_start();
?>

<html>
	<head>
		<title>Admin Login</title>
    <link rel="stylesheet" href="as.css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
	</head>

<body>
<div class="lf">
	<form method="post" action="login.php" class="lg">
  <div class="imgcontainer">
    <img src="img_avatar2.png" alt="Avatar" class="avatar">
  </div>

  <div class="lcon">
    <label for="uname"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="user_name" required>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="user_pass" required>

    <button type="submit" name="login">Login</button>

  </div>

</form>
</div>
</body>
</html>
<?php
include("../dbcon.php");

if(isset($_POST['login'])){

	$user_name = mysql_real_escape_string($_POST['user_name']);
	$user_pass = mysql_real_escape_string($_POST['user_pass']);

	$encrpt = md5($user_password);

	$admin_query = "select * from login where
	uname='$user_name' AND pwd='$user_pass'";

	$run = mysql_query($admin_query);

	if(mysql_num_rows($run)>0){


	$_SESSION['user_name']=$user_name;

	echo "<script>window.open('index.php','_self')</script>";
	}
	else {

	echo "<script>alert('User name or password is incorrect')</script>";

	}
}


?>
