<?php
session_start();

if(!isset($_SESSION['user_name'])){

header("location: login.php");
}
else {
?>

<html>
	<head>
		<title>New post</title>

	<link rel="stylesheet" href="as.css" />
	</head>

<body>
<?php include("common.php") ?>

<div id="cn">

	<div class="container">
  <form method="POST" action="newpost.php" enctype="multipart/form-data">
    <label for="fname">Title</label>
    <input type="text"  name="title" placeholder="Title.......">

    <label for="lname">Category</label>
    <input type="text" name="cat" placeholder="Category......">

		<label for="lname">Tags</label>
    <input type="text" name="tag" placeholder="Tag....">

		<label for="lname">Photo</label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <input type="file" name="image">
<br><br>
    <label for="subject">Cotent</label>
    <textarea  name="con" placeholder="Write something.." style="height:200px"></textarea>

    <input type="submit" name="submit" value="Publish"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  </form>
</div>


</div>
  </body>
  </html>
  <?php
  include("../dbcon.php");

  if(isset($_POST['submit'])){

  	 $t = $_POST['title'];
		 $c=$_POST['cat'];
		 $tg=$_POST['tag'];
		 $cn=$_POST['con'];
		 $post_image= $_FILES['image']['name'];
		 $image_tmp= $_FILES['image']['tmp_name'];
  	 $d= date('y-m-d');
		 $a=$_SESSION['user_name'];


  	if($t=='' or $c=='' or
  	$t=='' or $cn=='' ){

  	echo "<script>alert('Any of the fields is empty')</script>";

  	exit();

  	}
  	else {

  	move_uploaded_file($image_tmp,"../images/$post_image");

  	$insert_query = "insert into allpost
  	(title,category,tags,content,photos,dt,author) values
  	('$t','$c','$tg','$cn','$post_image','$d','$a')";


  	if(mysql_query($insert_query)){
  	echo "<script>alert('Post Published Successfully')</script>";
  	echo "<script>window.open('index.php','_self')</script>";

  	}


  	}



  }




  ?>
  <?php } ?>
