<div id="hd">
<a href="index.php">
<h1>Welcome to Infiniti Admin Panel</h1></a>
</div>

<div id="sb">
  <ul> <li>
Hello, <?php echo $_SESSION['user_name']; ?> <br><br> </li>

  <li><a  href="index.php">View posts</a></li>
  <li><a href="newpost.php?insert=insert">New Post</a></li>
  <li><a href="logout.php">Logout</a></li>
</ul>
</div>
