<?php
session_start();

if(!isset($_SESSION['user_name'])){

header("location: login.php");
}
else {
?>
<html>
	<head>
		<title>Update</title>

	<link rel="stylesheet" href="as.css" />
	</head>

<body>
<?php include("common.php") ?>


<div id="cn">
  <?php

  include("../dbcon.php");

  if(isset($_GET['edit'])){

  	$edit_id = $_GET['edit'];

  	$edit_query = "select * from allpost where pid='$edit_id'";

  	$run_edit = mysql_query($edit_query);

  	while ($ud=mysql_fetch_array($run_edit)){

			$t1 = $ud['title'];
			$c1 = $ud['category'];
			$tg1 = $ud['tags'];
			$p1 = $ud['photos'];
			$cn1=$ud['content'];

  }
  }

  ?>

		<div class="container">
	  <form  method="post" action="update.php?edit_form=<?php echo $edit_id; ?>" enctype="multipart/form-data">
	    <label for="fname">Title</label>
	    <input type="text"  name="title" value="<?php echo $t1; ?>">

	    <label for="lname">Category</label>
	    <input type="text" name="cat" value="<?php echo $c1; ?>">

			<label for="lname">Tags</label>
	    <input type="text" name="tag" value="<?php echo $tg1; ?>">

			<label for="lname">Photo</label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	    <input type="file" name="image"><img src="../images/<?php echo $p1?>" width="100" height="100">
	<br><br>
	    <label for="subject">Content</label>
	    <textarea  name="con" value="" style="height:200px"><?php echo $cn1; ?></textarea>

	    <input type="submit" name="submit" value="Update">
	  </form>
	</div>

  </div>
</body>
</html>
<?php

if(isset($_POST['submit'])){
   $id = $_GET['edit_form'];
	 $t = $_POST['title'];
	 $c=$_POST['cat'];
	 $tg=$_POST['tag'];
	 $cn=$_POST['con'];
	 $post_image= $_FILES['image']['name'];
	 $image_tmp= $_FILES['image']['tmp_name'];
	 $d= date('y-m-d');
	 $a=$_SESSION['user_name'];


	if($t=='' or $c=='' or
	$t=='' or $cn=='' ){

  echo "<script>alert('Any of the fields is empty')</script>";

  exit();

  }
  else {

  move_uploaded_file($image_tmp,"../images/$post_image");

  $update_query = "update allpost set title='$t',Category='$c',tags='$tg',content='$con',photos='$post_image',dt='$d',author='$a' where pid='$id'";

  if(mysql_query($update_query)){

  echo "<script>alert('Post has been updated')</script>";

  echo "<script>window.open('index.php','_self')</script>";

  }

  }
} }
?>
