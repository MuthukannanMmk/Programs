<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Contact</title>
    <link rel="stylesheet" href="css/stl.css">
    <link rel="icon" href="img/logo.png">
  </head>
  <body>
    <div class="">
      <?php include("header.php"); ?>
    </div>
    <div class="r">
      <div class="m">
        <div id="main_content">

        <h3>

        <p>You can contact us via the Mmk tech</p>
        <p>Address: 234.556.332.455</p>
        <p>Site xxxxxxxxxx</p>
        <p>You can use the below form to contact us more faster</p>
<center>

        <p><iframe frameborder="0" src="fb.php" width="70%" height="600px"></iframe></p></br>

        </h3>

        </center>
        </div>

      </div>

    </div>
    <div class="r1">
      <?php include("footer.php"); ?>
    </div>
  </body>

</html>
