<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Blog</title>
    <link rel="stylesheet" href="css/stl.css">
    <link rel="icon" href="img/logo.png">
  </head>
  <body>
    <div class="">
      <?php include("header.php"); ?>
    </div>

      <div class="m">
        <div id="main_content">



<?php

include("dbcon.php");

if(isset($_GET['id'])){

$page_id = $_GET['id'];

	$select_query = "select * from allpost where pid='$page_id'";

	$run_query = mysql_query($select_query);

while($row=mysql_fetch_array($run_query)){

	$pid = $row['pid'];
	$t = $row['title'];
	$c = $row['category'];
	$tg=$row['tags'];
	$d = date("d F, Y", strtotime($row['dt']));
	$a = $row['author'];
	$p = $row['photos'];
	$cn = substr($row['content'],0,300);




?>
<div class="card"><center>
<a href="pages.php?id=<?php echo $pid; ?>"><?php echo $t; ?></a><br></center>
<h4>
Category : <?php echo $c; ?> <br>
Tag : <?php echo $tg; ?><br>
Author : <?php echo $a; ?><br>
Published Date :<?php echo $d; ?><br><br>
<img src="images/<?php echo $p; ?>" > <br><br>
<p><?php echo $cn; ?></p></h4> <br><br>
<form action="comment.php" method="get" enctype="multipart/form-data">
  <input type="hidden" name="po" value="<?php echo $page_id; ?>">
<ul>
<input type="text" name="value" placeholder=" Enter your comments" size="25">&nbsp;&nbsp;&nbsp;&nbsp;
<input type="submit" name="cmt" value="Comment">
</ul>
</form>
<?php
$c_query = "select uid,cmt from cmts where pid='$page_id'";

$cr_query = mysql_query($c_query);

while($row1=mysql_fetch_array($cr_query)){

$n = $row1['uid'];
$cm = $row1['cmt'];
?><h3><?php echo $n; ?> : </h3> <?php echo $cm; ?>

  <?php
}
?>
</div>
<?php } } ?>
</div>

      </div>

  </body>
  <div class="r1">
    <?php include("footer.php"); ?>
  </div>
</html>
