<div class="header">
  <div class="hc">
    <img src="img/infi.png"height="80px"> <a href="index.php" class="txt">Infiniti</a>
  </div>
  <div class="hc1">
    <ul id="ul">
    	<li><a href="index.php">Home</a></li>
    	<li><a href="aboutas.php">About-us</a></li>
    	<li><a href="contact.php">Contact</a></li>
    </ul>
</div>
  <div id="searchbox">
  	<form action="search.php" method="get" enctype="multipart/form-data">
  	<ul>
  	<input type="text" name="value" placeholder=" search..." size="25">
  	<input type="submit" name="search" value="Search">
  	</ul>
  	</form>
  </div>
  <a href="login.php">Login</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <a href="logout.php">Logout</a>
  </div>
