<div id="footer">
<p align="center" ><font color="gray">&copy <?php echo date("Y"); ?>. Designed by Mmk</font></p>
</div>
