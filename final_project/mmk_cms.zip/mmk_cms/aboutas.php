<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>About</title>
    <link rel="stylesheet" href="css/stl.css">
    <link rel="icon" href="img/logo.png">
  </head>
  <body>
    <div class="">
      <?php include("header.php"); ?>
    </div>

      <div class="m">
        <div id="main_content">

          <h3>

           <p>This is a simple Content Management System</p>
           </h3>

        </div>

      </div>

  </body>
  <div class="r1">
    <?php include("footer.php"); ?>
  </div>
</html>
