<html>
<head>
  <link rel="stylesheet" href="admin/as.css">
</head>
<body bgcolor="#8eeff3" text="white">
<?php
function spamcheck($field)
  {

  $field=filter_var($field, FILTER_SANITIZE_EMAIL);

  if(filter_var($field, FILTER_VALIDATE_EMAIL))
    {
    return TRUE;
    }
  else
    {
    return FALSE;
    }
  }

  function spamcheck1($message)
  {
  if(empty($message))
    {
    return TRUE;
    }
  else
    {
    return FALSE;
    }
  }

    function spamcheck2($subject)
  {
  if(empty($subject))
    {
    return TRUE;
    }
  else
    {
    return FALSE;
    }
  }

?>
<br><br>
<h2 align="center">Feedback Form</h2>
<?php

if (!isset($_POST["submit"]))
  {
  ?>


  <form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">

        <div class="lcon">
          <label for="uname"><b>Email:</b></label>
          <input type="text" placeholder="Input a valid email id" name="from" required>

          <label for="psw"><b>Subject:</b></label>
          <input type="text" placeholder="Input your subject" name="subject" required>

          <label for="subject">Message:</label>
          <textarea  name="message" placeholder="Input your Message." style="height:200px"></textarea>

          <button type="submit" name="submit" value="Submit Feedback">Submit Feedback</button>

        </div>

  </form>

  <?php
  }



else

  {

  if (isset($_POST["from"]))
    {

    $mailcheck = spamcheck($_POST["from"]);
    if ($mailcheck==FALSE)
      {
	echo "<script>alert('Empty or invalid email id!')</script>";
	echo "<script>window.open('fb.php','_self')</script>";
    exit();
	  }

	else
		if (isset($_POST["message"]))
    {
    $mailcheck1 = spamcheck1($_POST["message"]);
    if ($mailcheck1==TRUE)
      {

	echo "<script>alert('Message field cannot be empty!')</script>";
	echo "<script>window.open('fb.php','_self')</script>";
	exit();
      }
	 else
	if (isset($_POST["subject"]))
    {
    $mailcheck2 = spamcheck2($_POST["subject"]);
    if ($mailcheck2==TRUE)
      {

	echo "<script>alert('Subject field cannot be empty!')</script>";
	echo "<script>window.open('fb.php','_self')</script>";
	exit();
      }
	  }

	      else
      {
      $from = $_POST["from"]; // sender
      $subject = $_POST["subject"];
      $message = $_POST["message"];
      // message lines should not exceed 70 characters (PHP rule), so wrap it
      $message = wordwrap($message, 70);
      // send mail
      mail("mmk@gmail.com",$subject,$message,"From: $from\n");
	  	echo "<script>alert('Thank you for sending us feedback.')</script>";
	echo "<script>window.open('fb.php','_self')</script>";
      }
	  }

    }
  }
?>
</body>
</html>
