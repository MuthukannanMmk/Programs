<?php
session_start();
?>

<html>
	<head>
		<title>User Login</title>
    <link rel="stylesheet" href="admin/as.css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
	</head>

<body> <center>
<button onclick="myFunction1()">Sign-In</button>
<button onclick="myFunction2()">Sign-Up</button> </center>
<div id="si">
  <div class="lf">
  	<form method="post" action="login.php" class="lg">
    <div class="imgcontainer">
      <img src="admin/img_avatar2.png" alt="Avatar" class="avatar">
    </div>

    <div class="lcon">
      <label for="uname"><b>Username</b></label>
      <input type="text" placeholder="Enter Username" name="user_name" required>

      <label for="psw"><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="user_pass" required>

      <button type="submit" name="login">Login</button>

    </div>

  </form>
  </div>
</div>
<div id="su">
  <div class="lf">
  	<form method="post" action="login.php" class="lg">

    <div class="lcon">
      <label for="uname"><b>Username</b></label>
      <input type="text" placeholder="Enter Username" name="user_name1" required>

      <label for="uname"><b>Email</b></label>
      <input type="text" placeholder="Enter E-mail id.." name="user_email" required>

      <label for="psw"><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="user_pass1" required>

      <label for="psw"><b>Repeat Password</b></label>
      <input type="password" placeholder="Re-nter Password" name="user_rpass" required>

      <button type="submit" name="signup">Sign-Up</button>

    </div>

  </form>
  </div>
</div>
<script>
var x = document.getElementById("si");
var y = document.getElementById("su");
  y.style.display = "none";
function myFunction1() {
  y.style.display = "none";
  x.style.display = "block";
  }
  function myFunction2() {
    y.style.display = "block";
    x.style.display = "none";
  }
</script>

</body>

<?php
include("dbcon.php");

if(isset($_POST['login'])){

	$user_name = mysql_real_escape_string($_POST['user_name']);
	$user_pass = mysql_real_escape_string($_POST['user_pass']);
	$encrpt = md5($user_password);

	$admin_query = "select * from user where
	uname='$user_name' AND pwd='$user_pass'";

	$run = mysql_query($admin_query);

	if(mysql_num_rows($run)>0){


	$_SESSION['user_name']=$user_name;

	echo "<script>window.open('index.php','_self')</script>";
	}
	else {

	echo "<script>alert('User name or password is incorrect')</script>";

	}
}


if(isset($_POST['signup'])){

	$sun = mysql_real_escape_string($_POST['user_name1']);
	$sue = mysql_real_escape_string($_POST['user_email']);
	$sup = mysql_real_escape_string($_POST['user_pass1']);
	$surp = mysql_real_escape_string($_POST['user_rpass']);
	if($sup==$surp){
	$encrpt = md5($sup);

	$admin_query = "insert into user
	(uname,email,pwd) values
	('$sun','$sue','$sup')";

	$run = mysql_query($admin_query);

	if(mysql_num_rows($run)>0){
	$_SESSION['user_name']=$user_name;

	echo "<script>window.open('index.php','_self')</script>";
	}
	else {

	echo "<script>alert('Enter the valid information..')</script>";

	}
}
else {
	echo "<script>alert('Passwords not match')</script>";
}
}

?>
