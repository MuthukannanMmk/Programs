<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="css/stl.css">
    <link rel="icon" href="img/logo.png">
  </head>
  <body>
    <div class="">
      <?php include("header.php"); ?>
    </div>

      <div class="m">
        <div id="main_content">



        <?php

        include("dbcon.php");

        $select_posts = "select * from allpost";

        $run_posts = mysql_query($select_posts);

        while($row=mysql_fetch_array($run_posts)){

        	$pid = $row['pid'];
        	$t = $row['title'];
        	$c = $row['category'];
        	$tg=$row['tags'];
        	$d = date("d F, Y", strtotime($row['dt']));
        	$a = $row['author'];
        	$p = $row['photos'];
        	$cn = substr($row['content'],0,300);




        ?>
        <div class="card">
        <a href="pages.php?id=<?php echo $pid; ?>"><?php echo $t; ?></a>
        <h6> <?php echo $c; ?> , <?php echo $d; ?>. </h6><br>
        <img src="images/<?php echo $p; ?>" > <br>
        <p><?php echo $cn; ?></p>
        </div>
        <?php } ?>
        </div>

      </div>

  </body>
  <div class="r1">
    <?php include("footer.php"); ?>
  </div>
</html>
