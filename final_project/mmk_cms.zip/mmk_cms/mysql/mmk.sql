-- phpMyAdmin SQL Dump
-- version 2.11.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 28, 2019 at 03:39 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `mmk`
--

-- --------------------------------------------------------

--
-- Table structure for table `allpost`
--

DROP TABLE IF EXISTS `allpost`;
CREATE TABLE IF NOT EXISTS `allpost` (
  `pid` int(10) NOT NULL auto_increment,
  `title` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `tags` varchar(50) NOT NULL,
  `content` longtext NOT NULL,
  `photos` text NOT NULL,
  `dt` date NOT NULL,
  `author` varchar(50) NOT NULL,
  PRIMARY KEY  (`pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `allpost`
--

INSERT INTO `allpost` (`pid`, `title`, `category`, `tags`, `content`, `photos`, `dt`, `author`) VALUES
(1, 'C', 'Computer programming language', 'Coding', 'C is a general-purpose, procedural computer programming language supporting structured programming, lexical variable scope, and recursion, while a static type system prevents unintended operations.', 'c.png', '2019-08-28', 'mmk'),
(2, 'Mobile computing', 'Technology', 'Digital world', 'Mobile computing is human–computer interaction in which a computer is expected to be transported during normal usage, which allows for transmission of data, voice and video. Mobile computing involves mobile communication, mobile hardware, and mobile software. ', 'm.png', '2019-08-28', 'mmk'),
(3, 'PlayerUnknown''s Battlegrounds', 'Online game', 'PUBG', 'PlayerUnknown''s Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.', 'p.jpg', '2019-08-28', 'mmk');

-- --------------------------------------------------------

--
-- Table structure for table `cmts`
--

DROP TABLE IF EXISTS `cmts`;
CREATE TABLE IF NOT EXISTS `cmts` (
  `uid` varchar(50) NOT NULL,
  `pid` varchar(50) NOT NULL,
  `cmt` varchar(500) NOT NULL,
  KEY `uid` (`uid`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cmts`
--

INSERT INTO `cmts` (`uid`, `pid`, `cmt`) VALUES
('kannan', '1', 'c is a basic of program language??'),
('kannan', '2', 'What is cloud computing?'),
('kannan', '3', 'It is danger??');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE IF NOT EXISTS `login` (
  `uid` int(10) NOT NULL auto_increment,
  `uname` varchar(50) NOT NULL,
  `pwd` varchar(50) NOT NULL,
  PRIMARY KEY  (`uid`),
  UNIQUE KEY `uname` (`uname`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`uid`, `uname`, `pwd`) VALUES
(1, 'mmk', 'Mmk');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `uid` int(100) NOT NULL auto_increment,
  `uname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pwd` varchar(50) NOT NULL,
  PRIMARY KEY  (`uid`,`email`),
  KEY `uname` (`uname`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `uname`, `email`, `pwd`) VALUES
(1, 'kannan', 'mmk@gmail.com', 'Mmk'),
(2, 'kannan', 'mmk@gmail.com', 'Mmk');
